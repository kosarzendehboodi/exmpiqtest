
//button start add to varible startbtn
const startbtn = document.getElementById('substr');

//question form add to varible formhide
const formhide = document.getElementById('questionform');

////div question element add to varible questionelement
const questionelement = document.getElementById('questionConElm')

//when a click start button  run function  startQuestion
startbtn.addEventListener('click', startQuestion)

//run function
function startQuestion() {
    console.log('started');
    // class hide remove for div questionConElm
    questionelement.classList.remove('hide');
  // class hide +background
    formhide.classList.add('hide');

}


function setnextquestion() { }
function setPreviousQuestion() { }
function selectAnswer() { }
