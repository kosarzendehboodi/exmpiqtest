
//start elemet in script
//creat element container
let container = document.createElement('div')
container.classList.add('container')
document.querySelector('body').appendChild(container)
console.log(container)

//create div quiz
let questionel = document.createElement('div')
//set id for div quiz
questionel.setAttribute('id', 'questionConElm')
//set classlist hide for 
questionel.classList.add('hide')
container.appendChild(questionel)


//design  for questions
//create div quiz
let quiz = document.createElement('div')
//set id for div quiz
quiz.setAttribute('id', 'quiz')
quiz.classList.add('quiz')
questionel.appendChild(quiz)


//create div numquestion
let numQuestionel = document.createElement('div')
//set classlist for div quiz
numQuestionel.classList.add('numquestion')
//add a child quiz
quiz.appendChild(numQuestionel)

//add (h1>span)+h3+div.quizsub
let childnumquiz = document.createElement('h1')
childnumquiz.innerHTML = "question" + QuestionNumOf + " of 30";
numQuestionel.appendChild(childnumquiz)

//span in h1 
let childh1 = document.createElement('span')
//set id for span
childh1.setAttribute('id', 'QuestionNumOf')
childh1.innerHTML = 1;


//add h3  for numquestion++++
let childQuizH3 = document.createElement('h3');
childQuizH3.innerHTML = "Which figure will logically fill the empty box in the grid?";
numQuestionel.appendChild(childQuizH3)

//quizbox
//quizbox  for 1 question design++++
let quizboxs = document.createElement('div');
quizboxs.setAttribute('id', 'quizbox')
numQuestionel.appendChild(quizboxs)

//div for images  question& answer++++
let imageQuestions = document.createElement('div');
imageQuestions.classList('imageQuestions')
quizboxs.appendChild(imageQuestions)

//class for image in questions +++++
let questions = document.createElement('div');
questions.classList('questions')
let test2 = imageQuestions.appendChild(questions)
console.log(test2)
//add image  show question+++++
let picQuestion = document.createElement('div');
picQuestion.setAttribute('src', 'image/Images/1/test1.png')
questions.appendChild(picQuestion)


//div for answer +++++
let answers = document.createElement('div')
answers.setAttribute('id', 'answers')
imageQuestions.appendChild(answers)
//create div for picanswer
let p1 = document.createElement('p')
p1.setAttribute('id', 'p1')
answers.appendChild(p1)
//create div for picanswer2
let p2 = document.createElement('p')
p2.setAttribute('id', 'p2')
answers.appendChild(p2)
//pic answer3
let p3 = document.createElement('p')
p3.setAttribute('id', 'p3')
answers.appendChild(p3)
//pic answer4
let p4 = document.createElement('p')
p4.setAttribute('id', 'p4')
answers.appendChild(p4)
//pic answer5
let p5 = document.createElement('p')
p5.setAttribute('id', 'p5')
answers.appendChild(p5)
//pic answer6
let p6 = document.createElement('p')
p6.setAttribute('id', 'p6')
p6.classList.add('hide')
answers.appendChild(p6)




//create button  for next and perivous
let nextBack = document.createElement('div')
nextBack.setAttribute('id', 'nextBack')
numQuestionel.appendChild(nextBack)

//form in button per and next
let btnBackNext = document.createElement('form')
btnBackNext.setAttribute('id', 'btnBackNext')
nextBack.appendChild(btnBackNext)
//create backinput
let back = document.createAttribute('input')
back.setAttribute('name', 'back')
back.setAttribute('value', 'back')
back.setAttribute('type', 'button')
btnBackNext.appendChild(back)

//create nextinput
let next = document.createAttribute('input')
next.setAttribute('id', 'next')
next.setAttribute('type', 'button')
next.setAttribute('value', 'NEXT >')
btnBackNext.appendChild(next)



// create form for add information
let questionform = document.createElement('div')
questionform.setAttribute('id', 'questionform')
container.appendChild(questionform)

// div for title
let head = document.createElement('div')
head.classList('head')
questionform.appendChild(head)

//title iqtest add to head
let titleiq = document.createElement('h1')
//type title
titleiq.innerHTML = "IQ TEST";
head.appendChild(titleiq)

//form for information
let infoForm = document.createElement('form')
infoForm.setAttribute('id', 'newform')
questionform.appendChild(infoForm)

//inputs create name
//title info-name 
let titleInfoName = document.createElement('h3')
//type title
titleInfoName.innerHTML = "NAME:";
infoForm.appendChild(titleInfoName)
//input name type-text
let names = document.createAttribute('input')
names.setAttribute('id', 'name')
names.setAttribute('type', 'text')
names.setAttribute('placeholder', 'enter your name')
infoForm.appendChild(names)



//inputs create age
//title info-age
let titleInfoAge = document.createElement('h3')
//type title
titleInfoAge.innerHTML = "age:";
infoForm.appendChild(titleInfoAge)
//input age  type-text
let ages = document.createAttribute('input')
ages.setAttribute('id', 'age')
ages.setAttribute('type', 'text')
ages.setAttribute('placeholder', 'enter your age ')
infoForm.appendChild(ages)



let startbtnel = document.createAttribute('input')
startbtnel.setAttribute('id', 'substr')
startbtnel.setAttribute('type', 'button')
startbtnel.setAttribute('value', 'START')
infoForm.appendChild(startbtnel)












//button start add to varible startbtn
const startbtn = document.getElementById('substr');

//question form add to varible formhide
const formhide = document.getElementById('questionform');

////div question element add to varible questionelement
const questionelement = document.getElementById('questionConElm')

//when a click start button  run function  startQuestion
startbtn.addEventListener('click', startQuestion)

//run function
function startQuestion() {
    console.log('started');
    // class hide remove for div questionConElm
    questionelement.classList.remove('hide');
    // class hide +background
    formhide.classList.add('hide');

}


function setnextquestion() { }
function setPreviousQuestion() { }
function selectAnswer() { }
